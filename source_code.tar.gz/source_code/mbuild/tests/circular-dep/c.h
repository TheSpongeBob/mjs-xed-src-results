#if !defined(CCC_1)
# define CCC_1

# include "a.h"
#endif
