
function err2f1() {
  return er();
}

function err2f2() {
  return bar;
}
